/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package sokobang;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.*;

public class Main extends JFrame
{
JLabel lblUserName,lblMoveCount,lblCurrentlevel,lblActorImg,lblBoxImg,lblDiamondImg,lblWallImage;
JLabel lblInstruction1,lblInstruction2,lblInstruction3,lblUpArrow,lblDownArrow,lblleftArrow;
JLabel lblRightArrow;
JLabel lblGameBoardImg;
JPanel pnlGameBoard;
Box objBox;
ForWall objWall;
Diamond objEndPoint;
Actor objactor;


private int movetotal=0;
private final int offset=180;
private final int space=30;
private final int left_hit=1;
private final int right_hit=2;
private final int top_hit=3;
private final int bottom_hit=4;
private ArrayList alWalls=new ArrayList();
private ArrayList alBaggs=new ArrayList();
private ArrayList alAreas=new ArrayList();
private final int LEFT_COLLISION=1;
private final int RIGHT_COLLISION=2;
private final int TOP_COLLISION=3;
private final int BOTTON_COLLISION=4;
private int width=0;
private int heigh=0;
private boolean fullstatus=false;
String completelevel="";
Game_Level GL=new Game_Level();


public Main()        /// constractor  //   // to work the window //
{
 this.setTitle("Sokoban_Game");
 this.setSize(600, 500);     // (width, height) //
 this.setLayout(null);
 lblUserName=new JLabel("Sokoban");
 lblMoveCount=new JLabel();
 lblCurrentlevel=new JLabel();
 lblUserName.setBounds(20,60,100,30); // (setBounds)to place the label //
 this.add(lblUserName);
 lblMoveCount.setBounds(20,60,100,30);
 this.add(lblMoveCount);
 lblCurrentlevel.setBounds(20,100,100,30);
 this.add(lblCurrentlevel);
 pnlGameBoard=new JPanel();
 pnlGameBoard.setBounds(130,20,350,430);
 this.add(pnlGameBoard);
 lblGameBoardImg=new JLabel();
 lblGameBoardImg.setBounds(10,110,350,430);
 lblInstruction1=new JLabel("Use Arrow Key");
 lblInstruction1.setBounds(10,180,100,30);
 this.add(lblInstruction1);
 lblUpArrow=new JLabel(new ImageIcon("UP.PNG"));
 lblUpArrow.setBounds(30,210,30,30);
 this.add(lblUpArrow);
 lblleftArrow=new JLabel(new ImageIcon("Left.PNG"));
 lblleftArrow.setBounds(10,230,30,30);
 this.add(lblUpArrow);
 lblRightArrow=new JLabel(new ImageIcon("Right.PNG"));
 lblRightArrow.setBounds(50,230,30,30);
 this.add(lblRightArrow);
 lblDownArrow=new JLabel(new ImageIcon("Down.PNG"));
 lblDownArrow.setBounds(30,250,30,30);
 this.add(lblDownArrow);
 lblInstruction2=new JLabel("Restart Level");
 lblInstruction2.setBounds(10,280,100,30);
 this.add(lblInstruction2);
  lblInstruction3=new JLabel("Press R");
 lblInstruction3.setBounds(10,300,100,30);
 this.add(lblInstruction3);



 Box bts=new Box(30,30);
 lblBoxImg=new JLabel(new ImageIcon(bts.getImage()));
 lblBoxImg.setSize(30,30);
 ForWall wing= new ForWall(30,30);
 lblWallImage =new JLabel(new ImageIcon(wing.getImage()));
 lblWallImage.setSize(30,30);
 Diamond air= new Diamond (30,30);
 lblDiamondImg=new JLabel(new ImageIcon(air.getImage()));
 lblDiamondImg.setSize(30,30);
 Actor RJ=new Actor(30,30);
  lblActorImg=new JLabel(new ImageIcon(RJ.getImage()));


 completelevel  =GL.level_1;
 lblCurrentlevel.setText("Level 1");
 startGameBoard(completelevel);     // startGameBoard-called the method //
 pnlGameBoard.add(lblGameBoardImg);
 pnlGameBoard.addKeyListener(new Arrowkey_MovingAdapter());
 pnlGameBoard.setFocusable(true);
 this.setVisible(true);
}
public final void startGameBoard(String  level)
{
    int x=offset;
    int y=130;
    for(int i=0; i<level.length(); i++)
    {
        char item=level.charAt(i);
        if(item == '\n')
        {
            y +=space;
            if (this.width<x)
            {
                this.width=x;
            }
            x=offset;
        }
        else if(item == '#')
        {
            objWall = new ForWall(x,y);
            alWalls.add(objWall);
            x+=space;
        }
        else if(item == '$')
        {
            objBox = new Box(x,y);
            alBaggs.add(objBox);
            x +=space;
        }
        else if (item == 'a')
        {
            objEndPoint = new Diamond(x,y);
            alAreas.add(objEndPoint);
            x += space;
        }
        else if(item == '@')
        {
            objactor = new Actor(x,y);
            x += space;
        }
        else if (item==' ')
        {
            x += space;
        }
        heigh=y;
    }
}

public void buildLevel_Map(Graphics g)
{
    Graphics2D g2D = (Graphics2D) g;
    ImageIcon iia =new ImageIcon("WallPaper1.jpg");
    Image img = iia.getImage();
    g2D.drawImage(img, 130,20, null);
    g2D.fillRect(0,0,lblGameBoardImg.getWidth(),lblGameBoardImg.getHeight());
    ArrayList alLevelMap=new ArrayList();
    alLevelMap.addAll(alWalls);
    alLevelMap.addAll(alAreas);
    alLevelMap.addAll(alBaggs);
    alLevelMap.add(objactor);
    for(int i=0; i<alLevelMap.size(); i++)
    {
        Arrowclass item=(Arrowclass)alLevelMap.get(i);
        if((item instanceof Actor) || (item instanceof Box))
        {
            g2D.drawImage(item.getImage(),item.getX() +2,item.getY()+2,lblGameBoardImg);
        }
        else
        {
            g2D.drawImage(item.getImage(), item.getX(), item.getY(), lblGameBoardImg);
        }
        if(fullstatus)
        {
         g2D.setColor(new Color(0,0,0));
         g2D.drawString("Complete", 25, 20);
         if(completelevel.equals("level1"))
         {
             completelevel="level2";
             startGameBoard(completelevel);
         }
         else if(completelevel.equals("level2"))
         {
             completelevel="level3";
             startGameBoard(completelevel);
         }
         else if(completelevel.equals("level3"))
         {
             completelevel="level4";
             startGameBoard(completelevel);
         }
         else
         {
             completelevel="level5";
             startGameBoard(completelevel);
         }
        }
    }
}

@Override
    public void paint(Graphics g)
    {
         Graphics2D g2d=(Graphics2D)g;
         super.paint(g2d);
         buildLevel_Map(g2d);
    }
    class Arrowkey_MovingAdapter extends KeyAdapter
    {
@Override
    public void keyPressed(KeyEvent e)
    {
    if(fullstatus){
        return;
    }
        int key=e.getKeyCode();
        if (key==KeyEvent.VK_LEFT){
            if (checkWallCollision(objactor,LEFT_COLLISION)){
                JOptionPane.showMessageDialog(null, "LeftWall");
                return;
            }
            if(checkBagCollision(LEFT_COLLISION)){
                JOptionPane.showMessageDialog(null,"LeftWall");
                return;
            }
            movetotal+=1;
            objactor.move(-space,0);

        }else if(key== KeyEvent.VK_RIGHT){
            if (checkWallCollision(objactor,RIGHT_COLLISION)){
                JOptionPane.showMessageDialog(null, "RightWall");
                return;
            }
            if(checkBagCollision(RIGHT_COLLISION)){
                JOptionPane.showMessageDialog(null,"RightWall");
                return;
            }
            movetotal+=1;
            objactor.move(space,0);
             }else if (key== KeyEvent.VK_UP){
            if (checkWallCollision(objactor,TOP_COLLISION)){
                JOptionPane.showMessageDialog(null, "TopWall");
                return;
            }
            if(checkBagCollision(TOP_COLLISION)){
                JOptionPane.showMessageDialog(null,"ToptWall");
                return;
            }
            movetotal+=1;
            objactor.move(0,-space);
            }
        else if(key== KeyEvent.VK_DOWN){
            if (checkWallCollision(objactor,BOTTON_COLLISION)){
                JOptionPane.showMessageDialog(null, "BottonWall");
                return;
            }
            if(checkBagCollision(BOTTON_COLLISION)){
                JOptionPane.showMessageDialog(null,"BottonWall");
                return;
            }
            movetotal+=1;
            objactor.move(0,space);
        } else if(key == KeyEvent.VK_R)
        {
            nextLevel();
        }
        lblMoveCount.setText(String.valueOf(movetotal));
        repaint();
}

}
private boolean checkWallCollision(Arrowclass player,int type)
{
    if (type==LEFT_COLLISION){
        for (int i=0; i<alWalls.size(); i++){
            ForWall wall=(ForWall) alWalls.get(i);
            if(objactor.islefttocollision(wall)){
                return true;
            }
        }
        return false;
    }else if (type == RIGHT_COLLISION){
         for (int i=0; i<alWalls.size(); i++){
            ForWall wall=(ForWall) alWalls.get(i);
            if(objactor.isrighttocollision(wall)){
                return true;
            }
        }
        return false;
    }else if(type == TOP_COLLISION){
         for (int i=0; i<alWalls.size(); i++){
            ForWall wall=(ForWall) alWalls.get(i);
            if(objactor.istopttocollision(wall)){
                return true;
            }
        }
        return false;
    }else if(type ==BOTTON_COLLISION){
       for (int i=0; i<alWalls.size(); i++){
            ForWall wall=(ForWall) alWalls.get(i);
            if(objactor.checkbutton(wall)){
                return true;
            }
            return false;
        }        
        }
        return false;
    }

    private boolean checkBagCollision(int collision_type)
    {
    if(collision_type==LEFT_COLLISION){
      for(int i=0; i<alBaggs.size(); i++){
          Box bag=(Box) alBaggs.get(i);
          if(objactor.islefttocollision(bag)){
              for(int j=0; j<alBaggs.size(); j++){
                  Box item=(Box) alBaggs.get(j);
                  if(!bag.equals(item)){
                      if(bag.islefttocollision(item)){
                          return true;
                      }
                  }
                  if(checkWallCollision(bag,LEFT_COLLISION)){
                      return true;
                  }
              }
              bag.move(-space,0);
              isLevelComplete();
          }
      }

      return false;
    }
    else if(collision_type==RIGHT_COLLISION){
      for(int i=0; i<alBaggs.size(); i++){
          Box bag=(Box) alBaggs.get(i);
          if(objactor.isrighttocollision(bag)){
              for(int j=0; j<alBaggs.size(); j++){
                  Box item=(Box) alBaggs.get(j);
                  if(!bag.equals(item)){
                      if(bag.isrighttocollision(item)){
                          return true;
                      }
                  }
                  if(checkWallCollision(bag,RIGHT_COLLISION)){
                      return true;
                  }
              }
              bag.move(space,0);
              isLevelComplete();
          }
      }
      return false;
      }
      else if(collision_type==TOP_COLLISION){
            for(int i=0; i<alBaggs.size(); i++){
                Box bag=(Box) alBaggs.get(i);
                if(objactor.istopttocollision(bag)){
                    for(int j=0; j<alBaggs.size(); j++){
                        Box item=(Box)alBaggs.get(j);
                        if(!bag.equals(item)){
                            if(bag.istopttocollision(item)){
                                return true;
                            }
                        }
                        if(checkWallCollision(bag,TOP_COLLISION)){
                            return true;
                        }
                    }
                    bag.move(0,-space);
                    isLevelComplete();
                }
            }
            return false;
        }
        else if(collision_type==BOTTON_COLLISION){
            for(int i=0; i<alBaggs.size(); i++){
                Box bag=(Box) alBaggs.get(i);
                if(objactor.checkbutton(bag)){
                    for(int j=0; j<alBaggs.size(); j++){
                        Box item=(Box)alBaggs.get(j);
                        if(!bag.equals(item)){
                            if(bag.checkbutton(item)){
                                return true;
                            }
                        }
                        if(checkWallCollision(bag,BOTTON_COLLISION)){
                            return true;
                        }
                    }
                    bag.move(0,space);
                    isLevelComplete();
                }
            }
        }

    return false;
}

    public void isLevelComplete(){
        int num=alBaggs.size();
        int compl=0;
        for(int i=0; i<num; i++){
            Box bag=(Box) alBaggs.get(i);
            for(int j=0; j<num; j++){
                Diamond area=(Diamond) alAreas.get(j);
                if(bag.getX()== area.getX() && bag.getY() ==area.getY()){
                    compl+=1;
                }
            }
        
        if(compl==num){
            fullstatus=false;
            if(completelevel.equals(GL.level_1)){
                completelevel=GL.level_2;
                lblGameBoardImg.setText("Level_2");
                startGameBoard(completelevel);
            }else if(completelevel.equals(GL.level_2)){
                completelevel=GL.level_3;
                lblGameBoardImg.setText("Level_3");
                 startGameBoard(completelevel);
        } else if(completelevel.equals(GL.level_3)){
                completelevel=GL.level_4;
                lblGameBoardImg.setText("Level_4");
                 startGameBoard(completelevel);
       }else if(completelevel.equals(GL.level_4)){
                completelevel=GL.level_5;
                lblGameBoardImg.setText("Level_5");
                 startGameBoard(completelevel);
       }else if(completelevel.equals(GL.level_5)){
                completelevel=GL.level_5;
                lblGameBoardImg.setText("Level_5");
                  startGameBoard(completelevel);
       }
        JOptionPane.showMessageDialog(null,"LevelComplete");
                nextLevel();
                repaint();
        }
    }
}
    public void nextLevel(){
        alAreas.clear();
        alBaggs.clear();
        alWalls.clear();
        startGameBoard(completelevel);
        movetotal=0;
        if(fullstatus){
            fullstatus=false;
        }
    }
    public static void main(String[] args) throws IOException{
        Main objsoko=new Main();
    }
}


