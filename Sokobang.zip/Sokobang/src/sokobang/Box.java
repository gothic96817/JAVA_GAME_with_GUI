/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package sokobang;

/**
 *
 * @author Gothic
 */
import java.awt.Image;
import java.net.URL;
import javax.swing.ImageIcon;
public class Box extends Arrowclass
{
    public Box(int x, int y)
    {
    super(x,y);
    ImageIcon ico=new ImageIcon("box.png");
    Image img=ico.getImage();
    this.setImage(img);
    }
public void move (int x, int y)
{
    int nx = this.getX()+x;
    int ny = this.getY()+y;
    this.setX(nx);
    this.setY(ny);
}
}