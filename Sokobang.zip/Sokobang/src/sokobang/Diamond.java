/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package sokobang;

/**
 *
 * @author Gothic
 */
import java.awt.Image;
import java.net.URL;
import javax.swing.ImageIcon;
public class Diamond extends Arrowclass
{
public Diamond (int x, int y)
{
    super(x,y);
    ImageIcon ico=new ImageIcon("diamond.png");
    Image img=ico.getImage();
    this.setImage(img);
}
}
