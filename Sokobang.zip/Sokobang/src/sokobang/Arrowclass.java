/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package sokobang;

/**
 *
 * @author Gothic
 */
import java.awt.Image;
public class Arrowclass {
    private final int space=30;
        private int x;
        private int y;
        private Image Image;

        public Arrowclass(int x,int y)
        {
            this.x=x;
            this.y=y;
        }
        public Image getImage()
        {
            return Image;
        }
        public void setImage(Image Image)
        {
            this.Image=Image;
        }
        public int getX()
        {
            return x;
        }

        public void setX(int x)
        {
            this.x=x;
        }

        public int getY()
        {
            return y;
        }

        public void setY(int y){
            this.y=y;
        }

        public boolean islefttocollision(Arrowclass actor)
        {
            if ((this.getX()-space == actor.getX()) && (this.getY()==actor.getY()))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public boolean isrighttocollision(Arrowclass actor)
        {
            if ((this.getX()+space == actor.getX()) && (this.getY()==actor.getY()))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public boolean istopttocollision(Arrowclass actor)
        {
            if ((this.getY()-space == actor.getY()) && (this.getX()==actor.getX()))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public boolean checkbutton(Arrowclass actor)
        {
            if ((this.getY()+space == actor.getY()) && (this.getX()==actor.getX()))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
}
