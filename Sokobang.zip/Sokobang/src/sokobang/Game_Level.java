/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package sokobang;

/**
 *
 * @author DELL
 */
public class Game_Level
{
public String level_1="##################\n"
                     +"# a              #\n"
                     +"#   $    ##      #\n"
                     +"#                #\n"
                     +"#       @        #\n"
                     +"#                #\n"
                     +"##################\n";

public String level_2="##############################\n"
                     +"#       a                    #\n"
                     +"#   $         #              #\n"
                     +"#             #     @        #\n"
                     +"#    $   a    #              #\n"
                     +"#                            #\n"
                     +"##############################\n";

public String level_3= "####################\n"
                      +"#                  #\n"
                      +"#    a       $ @   #\n"
                      +"#      a   $   #   #\n"
                      +"#                  #\n"
                      +"#                  #\n"
                      +"####################\n";

public String level_4= "#######################\n"
                      +"#    a                #\n"
                      +"#           $    @    #\n"
                      +"#      a      #       #\n"
                      +"#         $           #\n"
                      +"#                     #\n"
                      +"#######################\n";

public String level_5= "####################\n"
                      +"#    a             #\n"
                      +"#      $           #\n"
                      +"#          #   @   #\n"
                      +"#    a             #\n"
                      +"#       $          #\n"
                      +"#                  #\n"
                      +"#                  #\n"
                      +"####################\n";
}

