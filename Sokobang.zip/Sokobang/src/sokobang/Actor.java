/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package sokobang;

/**
 *
 * @author Gothic
 */

import java.awt.Image;
import java.net.URL;
import javax.swing.ImageIcon;
public class Actor extends Arrowclass{
public Actor(int x, int y)
{
    super(x,y);
    URL jjk=this.getClass().getResource("actor.png");
    ImageIcon ico=new ImageIcon("actor.png");
    Image img=ico.getImage();
    this.setImage(img);
}
public void move(int x, int y)
{
    int nx=this.getX()+x;
    int ny=this.getY()+y;
    this.setX(nx);
    this.setY(ny);
}
}
